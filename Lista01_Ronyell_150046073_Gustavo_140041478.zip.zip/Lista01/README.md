Para executar um arquivo primeiro é necessário estar nessa pasta
1 - g++ -o <nome do executavel> <nome do arquivo .cpp>
2 - ./<nome_executavel>
